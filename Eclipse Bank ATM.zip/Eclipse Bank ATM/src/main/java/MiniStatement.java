

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.swing.*;
import java.sql.*;

public class MiniStatement extends JFrame implements ActionListener{
 
    JButton b1, b2;
    JLabel l1;
    static String cardnum;
   static String date2;
   static  String type2;
   static String amount2;

    MiniStatement(String pin){
        
        
        
        getContentPane().setBackground(Color.WHITE);
        setSize(400,600);
        setLocation(20,20);
        
        l1 = new JLabel();
        add(l1);
        
        JLabel l2 = new JLabel("Project Bank");
        l2.setBounds(150, 20, 100, 20);
        add(l2);
        
        JLabel l3 = new JLabel();
        l3.setBounds(20, 80, 300, 20);
        add(l3);
        
        JLabel l4 = new JLabel();
        l4.setBounds(20, 400, 300, 20);
        add(l4);
        

        try{
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from login where pin = '"+pin+"'");
            while(rs.next()){
                
                l3.setText("Card Number:    " + rs.getString("cardno").substring(0, 4) + "XXXXXXXX" + rs.getString("cardno").substring(12));
                String cardno1 = rs.getString("cardno");

                cardnum = cardno1;

            }
        }catch(Exception e){}
        	 
        try{
            
            int balance = 0;
            Conn c1  = new Conn();
            ResultSet rs = c1.s.executeQuery("SELECT * FROM bank where pin = '"+pin+"'");
            while(rs.next()){
                
                String date1 = rs.getString("date");
                String type1 = rs.getString("type");
                String amount1 = rs.getString("amount");
                date2=date1;
                type2=type1;
                amount2=amount1;

                l1.setText(l1.getText() + "<html>"+rs.getString("date")+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("type") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("amount") + "<br><br><html>");

                if(rs.getString("type").equals("Deposit")){
                    balance += Integer.parseInt(rs.getString("amount"));
              
                        
                }else{
                    balance -= Integer.parseInt(rs.getString("amount"));
                }
            }
            l4.setText("Your total Balance is Rs "+balance);

        }catch(Exception e){
            e.printStackTrace();
        }
        

        
        
        setLayout(null);
        b1 = new JButton("Exit");
        add(b1);
        
        b1.addActionListener(this);
        
        l1.setBounds(20, 140, 400, 200);
        b1.setBounds(20, 500, 100, 25);

//        try{
//            
//            PdfWriter.getInstance(doc,new FileOutputStream(ministatement.billpath+""+cardnum+".pdf" ));
//            doc.open();
//            Paragraph BankName = new Paragraph("Eclipse Bank\n");
//            doc.add(BankName);
//            Paragraph starline = new Paragraph("*****************************************");
//            doc.add(starline);
//            Paragraph details = new Paragraph("Card NO: "+cardnum.substring(0,4)+"XXXXXXXX");
//            doc.add(details);
//            PdfPTable tb=new PdfPTable(3);
////            String a = l1.getText();
////            tb.addCell(a);
//            doc.add(tb);
//            doc.add(starline);
//            Paragraph thanksmsg = new Paragraph("Thank you - visit again");
//            doc.add(thanksmsg);
//            
//           
//        
//        }catch(Exception e){
//            JOptionPane.showMessageDialog(null,e);
//        }

                      System.out.println(cardnum);
                      System.out.println(amount2);
                     System.out.println(date2);
                      System.out.println(type2);
                      
                      
                      try {
          
            Document doc = new Document();
            
            
            PdfWriter.getInstance(doc, new FileOutputStream("D:/Receipt.pdf"));
            
            doc.open();


            Paragraph bankName = new Paragraph("              Eclipse Bank");
            doc.add(bankName);


            Paragraph starline = new Paragraph("*****************************************");
            doc.add(starline);


            Paragraph details = new Paragraph("Your Last Transaction Receipt for Card NO: " + cardnum + "XXXXXXXX");
            doc.add(details);

           
            doc.add(starline);
            
            PdfPTable tb = new PdfPTable(3);
            

            PdfPCell cell1 = new PdfPCell(new Paragraph(" Date "));
            PdfPCell cell2 = new PdfPCell(new Paragraph(" Type "));
            PdfPCell cell3 = new PdfPCell(new Paragraph(" Amount "));
            PdfPCell cell4 = new PdfPCell(new Paragraph(date2));
            PdfPCell cell5 = new PdfPCell(new Paragraph(type2));
            PdfPCell cell6= new PdfPCell(new Paragraph(amount2));

            
            
        
             tb.addCell(cell1);
             tb.addCell(cell2);
             tb.addCell(cell3);
             tb.addCell(cell4);
             tb.addCell(cell5);
             tb.addCell(cell6);


            doc.add(tb);

            doc.add(starline);


            Paragraph thanksmsg = new Paragraph("Thank you - visit again");
            doc.add(thanksmsg);

            doc.close();

            System.out.println("PDF created successfully.");

        } catch (DocumentException | FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void actionPerformed(ActionEvent ae){
        this.setVisible(false);
    }
    
    public static void main(String[] args){
        new MiniStatement("").setVisible(true);
    }
    
}
